let RespondCodes = {
    Response_SUCCESS: "00",
    Respond_THIS_USER_ALREADY_REGISTERED: "06",
    Respond_THIS_USER_NOT_REGISTERED_YET   : "07",
    Respond_INTERNAL_SERVER_FAIL  :"15",
    Respond_DATA_SAVED  :"14",

    Respond_PASSWORD_MATCHED  :"17",
    Respond_PASSWORD_NOT_MATCHED  :"18",

    Respond_USERNAME_AND_OTP_VERIFIED  :"19",

    Respond_NEW_PASSWORD_CREATED_AND_LOGIN_SUCCEED  :"20",

    Respond_NOT_AUTHORISED : "02"
}
